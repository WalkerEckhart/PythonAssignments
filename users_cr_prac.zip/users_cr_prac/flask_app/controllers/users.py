from flask_app import app
from flask import render_template, redirect, request, session
from flask_app.models import user # import entire file, rather than class, to avoid circular imports

# Create Users Controller



# Read Users Controller
@app.route('/user')
def show_all_users():
    user.User.get_all_users(request.form)
    return redirect('/show/user')

@app.route('/')
def index():
    user.User.create_user(request.form)
    return render_template('index.html')

@app.route('/show/user')
def user_page():
    users = user.User.get_all_users(None)
    return render_template('users.html', users=users)


# Update Users Controller
@app.route('/user/edit/<int:user_id>')
def edit_user(user_id):
    this_user = user.User.get_user_by_id(user_id)
    return render_template('edit.html', user = this_user)

@app.route ('/user/edit', methods=['POST'])
def post_user_edit():
    user.User.edit_user_data(request.form)
    return redirect('/show/user')


# Delete Users Controller
@app.route ('/user/delete/<int:user_id>')
def delete_user(user_id):
    user.User.delete_user_by_id(user_id)
    return redirect('/show/user')

# Notes:
# 1 - Use meaningful names
# 2 - Do not overwrite function names
# 3 - No matchy, no worky
# 4 - Use consistent naming conventions 
# 5 - Keep it clean
# 6 - Test every little line before progressing
# 7 - READ ERROR MESSAGES!!!!!!
# 8 - Error messages are found in the browser and terminal




# How to use path variables:
# @app.route('/<int:id>')
# def index(id):
#     user_info = user.User.get_user_by_id(id)
#     return render_template('index.html', user_info)

# Converter -	Description
# string -	Accepts any text without a slash (the default).
# int -	Accepts integers.
# float -	Like int but for floating point values.
# path 	-Like string but accepts slashes.