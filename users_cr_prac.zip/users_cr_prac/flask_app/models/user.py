
from flask_app import app
from flask_app.config.mysqlconnection import connectToMySQL
from flask import flash, session
# import re
# from flask_bcrypt import Bcrypt
# bcrypt = Bcrypt(app)
# The above is used when we do login registration, be sure to install flask-bcrypt: pipenv install flask-bcrypt


class User:
    db = "user_prac" #which database are you using for this project
    def __init__(self, data):
        self.id = data['id']
        self.first_name = data['first_name']
        self.last_name = data['last_name']
        self.email = data['email']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
        # What changes need to be made above for this project?
        #What needs to be added her for class association?



    # Create Users Models
    @classmethod
    def create_user(cls, data):
        query = """INSERT INTO users (first_name, last_name, email)
            VALUES (%(first_name)s, %(last_name)s, %(email)s);"""
        result = connectToMySQL(cls.db).query_db(query,data)
        return result

    # Read Users Models
    @classmethod
    def get_all_users(cls, data):
        query = """SELECT * FROM users;"""
        result = connectToMySQL(cls.db).query_db(query,data)
        users = []
        for user in result:
            users.append(cls(user))
        return(result)
    
    @classmethod 
    def get_user_by_id(cls, user_id):
        query = """SELECT * FROM users
        WHERE id = %(id)s;"""
        data = {'id': user_id}
        result = connectToMySQL(cls.db).query_db(query,data)
        return cls(result[0])


    # Update Users Models
    @classmethod
    def edit_user_data(cls, data):
        query = """UPDATE users
        SET first_name=%(first_name)s, last_name=%(last_name)s, email=%(email)s
        WHERE id = %(id)s"""
        result = connectToMySQL(cls.db).query_db(query,data)
        return result


    # Delete Users Models
    @classmethod
    def delete_user_by_id(cls,user_id):
        query = "DELETE FROM users WHERE id = %(id)s;"
        data = {'id': user_id}
        connectToMySQL(cls.db).query_db(query, data)
        return