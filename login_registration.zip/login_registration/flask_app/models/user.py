
from flask_app import app
from flask_app.config.mysqlconnection import connectToMySQL
from flask import flash, session
import re
from flask_bcrypt import Bcrypt
bcrypt = Bcrypt(app)
# The above is used when we do login registration, be sure to install flask-bcrypt: pipenv install flask-bcrypt

EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$') 
class User:
    db = "login_registration" #which database are you using for this project
    def __init__(self, data):
        self.id = data['id']
        self.first_name = data['first_name']
        self.last_name = data['last_name']
        self.email = data['email']
        self.password = data['password']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
        # What changes need to be made above for this project?
        #What needs to be added her for class association?
    



    # Create Users Models

    @classmethod
    def save_new_user(cls,data):
        if not cls.validate_user(data):
            return False
        user_data = cls.parse_user_data(data)
        query = """INSERT INTO users
        (first_name, last_name, email, password)
        VALUES (%(first_name)s, %(last_name)s, %(email)s, %(password)s);"""
        result = connectToMySQL(cls.db).query_db(query,user_data)
        session['user_id'] = result 
        session['user_name'] = f'{data["first_name"]} {data["last_name"]}'
        return result


    # Read Users Models
    # READ ALL
    @classmethod
    def get_all_users(cls):
        query = 'SELECT * FROM users;'
        result = connectToMySQL(cls.db).query_db(query)
        users = []
        for user in result:
            users.append(cls(user))
        return users
        
    # READ BY ID 
    @classmethod
    def get_user_by_id(cls, user_id):
        query = 'SELECT * FROM users WHERE id = %(id)s;'
        data = {'id': user_id}
        result = connectToMySQL(cls.db).query_db(query,data)
        return cls(result[0])

    # READ BY EMAIL   
    @classmethod
    def get_user_by_email(cls,email):
        query = 'SELECT * FROM users WHERE email = %(email)s;'
        data = {'email' : email}
        result = connectToMySQL(cls.db).query_db(query,data)
        print(result[0])
        return cls(result[0])

    # Update Users Models



    # Delete Users Models

    @staticmethod
    def parse_user_data(form):
        user_data = {
            'first_name': form['first_name'],
            'last_name': form['last_name'],
            'email': form['email'],
            'password': bcrypt.generate_password_hash(form['password']),
            'password_confirmation': bcrypt.generate_password_hash(form['password_confirmation']),
        }
        return user_data


    @staticmethod
    def validate_user(user):
        is_valid = True
        if len(user['first_name']) <= 1:
            flash('First name must not be empty or abbreviated.')
            is_valid = False
        if len(user['last_name']) <= 1:
            flash('Last name must not be empty or abbreviated.')
            is_valid = False
        if not EMAIL_REGEX.match(user['email']): 
            flash("Invalid email address!")
            is_valid = False
        if len(user['password']) <8:
            flash('Password must be at least 8 characters!')
            is_valid = False
        if (user['password']) != (user['password_confirmation']):
            flash('No matchy, no worky!')
            is_valid = False
        return is_valid
    
    @staticmethod
    def user_login(form):
        this_user = User.get_user_by_email(form['email'])
        if this_user:
            if bcrypt.check_password_hash(this_user.password, form['password']):
                session['user_id'] = this_user.id 
                session['user_name'] = f'{this_user.first_name} {this_user.last_name}'
                return True
        flash('Email and/or password not in records!')
        return False

