from flask_app import app
from flask_app.config.mysqlconnection import connectToMySQL
from flask_app.models import dojo
from flask import flash, session
import re
# import re
# from flask_bcrypt import Bcrypt
# bcrypt = Bcrypt(app)
# The above is used when we do login registration, be sure to install flask-bcrypt: pipenv install flask-bcrypt


class Ninja:
    db = "dojos_and_ninjas" #which database are you using for this project
    def __init__(self, data):
        self.id = data['id']
        self.first_name = data['first_name']
        self.last_name = data['last_name']
        self.age = data['age']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
        self.dojo_id = data['dojo_id']

    @staticmethod
    def validate_ninja(ninja):
        is_valid = True
        if len(ninja['first_name']) < 1:
            flash('First name must not be empty!')
            is_valid = False
        if len(ninja['last_name']) < 1:
            flash('Last name must not be empty!')
            is_valid = False
        if int(ninja['age']) < 18:
            flash('Ninjas must be at least 18 years old!')
            is_valid = False
        return is_valid


        # What changes need to be made above for this project?
        #What needs to be added her for class association?



    # Create Users Models
    @classmethod
    def save_ninja(cls, data):
        query = """INSERT INTO ninjas 
        (first_name, last_name, age, dojo_id) 
        VALUES (%(first_name)s, %(last_name)s, %(age)s, %(dojo_id)s);"""
        result = connectToMySQL(cls.db).query_db(query, data)
        return result


    # Read Users Models
    @classmethod
    def get_all_ninjas(cls):
        query = """SELECT * FROM ninjas;"""
        result = connectToMySQL(cls.db).query_db(query)
        ninjas = []
        for ninja in result:
            ninjas.append(cls(ninja))
        return ninjas 
    
        
    
    @classmethod
    def get_ninja_by_id(cls, ninja_id):
        query = """SELECT * FROM ninjas WHERE id = %(id)s;"""
        data = {'id': ninja_id}
        result = connectToMySQL(cls.db).query_db(query,data)
        return result


    # Update Users Models



    # Delete Users Models