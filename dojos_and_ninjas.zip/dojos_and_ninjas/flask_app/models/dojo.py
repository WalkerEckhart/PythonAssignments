from flask_app import app
from flask_app.config.mysqlconnection import connectToMySQL
from flask_app.models import ninja
from flask import flash, session

class Dojo:
    db = "dojos_and_ninjas"
    def __init__(self, data):
        self.id = data['id']
        self.name = data['name']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
        self.ninjas = []


        # What changes need to be made above for this project?
        #What needs to be added her for class association?



    # Create Users Models
    @classmethod
    def create_dojo(cls, data):
        query = """INSERT INTO dojos (name)
            VALUES (%(name)s);"""
        result = connectToMySQL(cls.db).query_db(query,data)
        return result


    # Read Users Models
    @classmethod
    def get_all_dojos(cls):
        query = "SELECT * FROM dojos;"
        result = connectToMySQL(cls.db).query_db(query)
        dojos = []
        for dojo in result:
            dojos.append(cls(dojo))
        return dojos
    

    @classmethod
    def show_ninjas_in_dojo(cls, id):
        data = {'id': id}
        query = "SELECT * FROM dojos LEFT JOIN ninjas ON ninjas.dojo_id = dojos.id WHERE dojos.id = %(id)s;"
        result = connectToMySQL('dojos_and_ninjas').query_db(query, data) 
        dojos = cls(result[0])
        for row_from_db in result:
            ninja_data = {
                "id": row_from_db["id"],
                "first_name": row_from_db["first_name"],
                "last_name": row_from_db["last_name"],
                "age": row_from_db["age"],
                "created_at": row_from_db["created_at"],
                "updated_at": row_from_db["updated_at"],
                "dojo_id": row_from_db["dojo_id"]
            }
            dojos.ninjas.append(ninja.Ninja(ninja_data))
        return dojos


    # Update Users Models



    # Delete Users Models