from flask_app import app
from flask import render_template, redirect, request, session
from flask_app.models import dojo

# Create
@app.route('/dojo/create', methods = ['POST'])
def add_dojo():
    dojo.Dojo.create_dojo(request.form)
    return redirect('/')

# Read
@app.route('/show/dojo/<int:dojo_id>')
def show_dojo_by_id(dojo_id):
    this_dojo = dojo.Dojo.show_ninjas_in_dojo(dojo_id)
    return render_template('dojo_roster.html', dojo = this_dojo)
